import type { KnipConfig } from 'knip'

/**
 * @see https://knip.dev/reference/configuration
 */
const config: KnipConfig = {
  compilers: {
    mdx: true,
  },
  workspaces: {
    web: {
      entry: [
        'scripts/**/*.{js,ts,mjs}',
        'bin/**/*.{js,ts,mjs}',
        'tsslint.config.ts',
        'dev-proxy.config.ts',
        'plugins/eslint/index.js',
        // Public surface consumed by the standalone Marketplace host.
        // The `!` suffix keeps these entries in `knip --production`.
        'app/components/plugins/marketplace/standalone/server.ts!',
        'app/components/plugins/marketplace/standalone/client.ts!',
      ],
      project: [
        '**/*.{js,mjs,cjs,jsx,ts,tsx,mts,cts,css,mdx}!',
        '!**/__mocks__/**!',
        '!**/__tests__/**!',
        '!**/*.stories.{js,jsx,ts,tsx,mdx}!',
        '!.storybook/**!',
        '!plugins/**!',
        '!test/**!',
        '!vitest.browser.setup.ts!',
        '!vitest.setup.ts!',
      ],
      ignore: ['public/**'],
      ignoreFiles: ['i18n-config/locale-resources/*.ts'],
      ignoreDependencies: ['@iconify-json/*', '@storybook/addon-onboarding'],
    },
  },
  /// keep-sorted
  rules: {
    binaries: 'warn',
    catalog: 'error',
    dependencies: 'error',
    devDependencies: 'warn',
    duplicates: 'error',
    enumMembers: 'error',
    exports: 'error',
    files: 'error',
    namespaceMembers: 'error',
    nsExports: 'error',
    nsTypes: 'error',
    optionalPeerDependencies: 'error',
    types: 'error',
    unlisted: 'error',
    unresolved: 'error',
  },
}

export default config
