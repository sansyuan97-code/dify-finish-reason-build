import { defineConfig } from 'vite-plus'
import { lintConfig } from './lint.config'

const lintFiles = '*.{js,cjs,mjs,jsx,ts,cts,mts,tsx}'
const eslintFiles = '*.{json,jsonc,json5,md,yml,yaml,toml}'
const formatOnlyFiles = '*.{mdx,css,scss,less,html,vue,svelte,gql,graphql,hbs,handlebars}'
const checkFix = 'vp check --fix --no-error-on-unmatched-pattern'
const formatFix = 'vp fmt --no-error-on-unmatched-pattern'
const eslintFix =
  'eslint --fix --pass-on-unpruned-suppressions --no-error-on-unmatched-pattern --no-warn-ignored'

const nonFrontendIgnores = [
  '.agents/**',
  '.devcontainer/**',
  '/*.md',
  'api/**',
  'codecov.yml',
  'depot.json',
  'dify-agent/**',
  'docker/**',
  'docs/**',
  'scripts/**/*',
  '!scripts/check-web-production-unused-after-knip-fix.mjs',
  'sdks/php-client/**',
  'sdks/python-client/**',
]

const generatedIgnores = [
  '**/.next/**',
  '**/.vinext/**',
  '**/coverage/**',
  '**/dist/**',
  '**/storybook-static/**',
  'e2e/.auth/**',
  'e2e/cucumber-report/**',
  'eslint-suppressions.json',
  'oxlint-suppressions.json',
  'web/next/**',
  'web/next-env.d.ts',
  'web/public/embed.min.js',
  'web/public/pdf.worker.min.mjs',
  'web/public/vs/**',
]

const formatterUnstableInputs = ['web/app/components/develop/template/*.mdx']

export default defineConfig({
  lint: lintConfig,
  staged: {
    [lintFiles]: checkFix,
    [eslintFiles]: [eslintFix, formatFix],
    [formatOnlyFiles]: formatFix,
    '.vite-hooks/*': 'sh -n',
    'api/**/*.{py,pyi}': [
      // Format first so fixable long lines do not fail the API's E501 check.
      'uv run --locked --project api --dev ruff format --force-exclude',
      'uv run --locked --project api --dev ruff check --fix --force-exclude',
      'uv run --locked --project api --dev ruff format --force-exclude',
    ],
    'dify-agent/{src,examples,tests,docs}/**/*.py': [
      'uv run --locked --project dify-agent --dev ruff check --fix --force-exclude',
      'uv run --locked --project dify-agent --dev ruff format --force-exclude',
    ],
  },
  fmt: {
    ignorePatterns: [...nonFrontendIgnores, ...generatedIgnores, ...formatterUnstableInputs],
    singleQuote: true,
    semi: false,
    sortImports: {
      groups: [
        'type-import',
        ['type-parent', 'type-sibling', 'type-index', 'type-internal', 'type-subpath'],
        'value-builtin',
        'value-external',
        ['value-internal', 'value-subpath'],
        ['value-parent', 'value-sibling', 'value-index'],
        ['side_effect_style', 'side_effect'],
        'unknown',
      ],
      newlinesBetween: false,
      sortSideEffects: false,
    },
    sortPackageJson: true,
    sortTailwindcss: {
      functions: ['cn', 'clsx', 'cva', 'tw', 'twMerge'],
      preserveDuplicates: false,
      stylesheet: 'web/app/styles/globals.css',
    },
  },
})
