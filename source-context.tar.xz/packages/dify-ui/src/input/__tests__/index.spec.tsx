import { userEvent } from 'vite-plus/test/browser'
import { render } from 'vitest-browser-react'
import { Field, FieldError, FieldLabel } from '../../field'
import { Form } from '../../form'
import { Input } from '../index'

describe('Input', () => {
  it('should show keyboard focus when read-only', async () => {
    const screen = await render(<Input aria-label="API key" defaultValue="sk-test" readOnly />)
    const input = screen.getByRole('textbox', { name: 'API key' })
    const restingBoxShadow = getComputedStyle(input.element()).boxShadow

    await userEvent.keyboard('{Tab}')

    await expect.element(input).toHaveFocus()
    await expect.poll(() => getComputedStyle(input.element()).boxShadow).not.toBe(restingBoxShadow)
  })

  it('should use Field invalid state', async () => {
    const screen = await render(
      <Field name="repositoryUrl" invalid>
        <FieldLabel>Repository URL</FieldLabel>
        <Input defaultValue="github.com/langgenius" />
      </Field>,
    )

    const input = screen.getByRole('textbox', { name: 'Repository URL' })

    await expect.element(input).toHaveAttribute('aria-invalid', 'true')
    await expect.element(input).toHaveAttribute('data-invalid')
  })

  it('should integrate with Field and Base UI Form validation', async () => {
    const onFormSubmit = vi.fn()
    const screen = await render(
      <Form aria-label="account form" onFormSubmit={onFormSubmit}>
        <Field name="email">
          <FieldLabel>Email</FieldLabel>
          <Input type="email" required />
          <FieldError match="valueMissing">Email is required.</FieldError>
        </Field>
        <button type="submit">Save</button>
      </Form>,
    )

    const input = screen.getByRole('textbox', { name: 'Email' })

    await screen.getByRole('button', { name: 'Save' }).click()

    await vi.waitFor(async () => {
      await expect.element(screen.getByText('Email is required.')).toBeInTheDocument()
      await expect.element(input).toHaveAttribute('aria-invalid', 'true')
      await expect.element(input).toHaveAttribute('data-invalid')
    })
    expect(onFormSubmit).not.toHaveBeenCalled()
  })
})
