import type { Meta, StoryObj } from '@storybook/react-vite'
import * as React from 'react'
import { expect, within } from 'storybook/test'
import { toast, ToastHost } from '.'
import { Button } from '../button'

const longToastTitle =
  'operation error S3: PutObject, exceeded maximum number of attempts, 3, StatusCode: 0, RequestID: , HostID: , request send failed'
const longToastDescription =
  'Put "https://plugin/assets/1bd032bb73218a5d141b80cab7111?x-id=PutObject": dial tcp 192.168.0.200:19000: connect: connection refused, icon small en_US failed to remap assets failed to store plugin asset'

const buttonClassName =
  'rounded-lg border border-divider-subtle bg-components-button-secondary-bg px-3 py-2 text-sm text-text-secondary shadow-xs outline-hidden transition-colors hover:bg-state-base-hover focus-visible:ring-2 focus-visible:ring-state-accent-solid'
const cardClassName =
  'flex min-h-[220px] flex-col gap-4 rounded-2xl border border-divider-subtle bg-components-panel-bg p-6 shadow-sm shadow-shadow-shadow-3'

const ExampleCard = ({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string
  title: string
  description: string
  children: React.ReactNode
}) => {
  return (
    <section className={cardClassName}>
      <div className="space-y-2">
        <div className="text-xs tracking-[0.18em] text-text-tertiary uppercase">{eyebrow}</div>
        <h3 className="text-base leading-6 font-semibold text-text-primary">{title}</h3>
        <p className="text-sm leading-6 text-text-secondary">{description}</p>
      </div>
      <div className="mt-auto flex flex-wrap gap-3">{children}</div>
    </section>
  )
}

const VariantExamples = () => {
  const createVariantToast = (type: 'success' | 'error' | 'warning' | 'info') => {
    const copy = {
      success: {
        title: 'Changes saved',
        description: 'Your draft is available to collaborators.',
      },
      error: {
        title: 'Sync failed',
        description: 'Check your network connection and try again.',
      },
      warning: {
        title: 'Storage almost full',
        description: 'You have less than 10% of workspace quota remaining.',
      },
      info: {
        title: 'Invitation sent',
        description: 'An email has been sent to the new teammate.',
      },
    } as const

    toast[type](copy[type].title, {
      description: copy[type].description,
    })
  }

  return (
    <ExampleCard
      eyebrow="Variants"
      title="Tone-specific notifications"
      description="Trigger the four supported tones from the shared viewport to validate iconography, gradient treatment, and copy density."
    >
      <button
        type="button"
        className={buttonClassName}
        onClick={() => createVariantToast('success')}
      >
        Success
      </button>
      <button type="button" className={buttonClassName} onClick={() => createVariantToast('info')}>
        Info
      </button>
      <button
        type="button"
        className={buttonClassName}
        onClick={() => createVariantToast('warning')}
      >
        Warning
      </button>
      <button type="button" className={buttonClassName} onClick={() => createVariantToast('error')}>
        Error
      </button>
    </ExampleCard>
  )
}

const StackExamples = () => {
  const createStack = () => {
    ;[
      {
        type: 'info' as const,
        title: 'Generating preview',
        description: 'The first toast compresses behind the newest notification.',
      },
      {
        type: 'warning' as const,
        title: 'Review required',
        description: 'A second toast should deepen the stack without breaking spacing.',
      },
      {
        type: 'success' as const,
        title: 'Ready to publish',
        description: 'The newest toast stays frontmost while older items tuck behind it.',
      },
    ].forEach((item) => {
      toast[item.type](item.title, {
        description: item.description,
      })
    })
  }

  const createBurst = () => {
    Array.from({ length: 5 }).forEach((_, index) => {
      toast[index % 2 === 0 ? 'info' : 'success'](`Background task ${index + 1}`, {
        description: 'Use this to inspect how the stack behaves near the host limit.',
      })
    })
  }

  const createVaryingHeightStack = () => {
    toast.error('Failed to publish the workflow', {
      description:
        'The workflow could not be published because several dependent resources are unavailable. Check the model provider credentials, reconnect the knowledge base, and try publishing again after every dependency is ready.',
    })
    toast.success('Short front toast', {
      description: 'Short message.',
    })
  }

  return (
    <ExampleCard
      eyebrow="Stack"
      title="Stacked viewport behavior"
      description="These examples mirror the Base UI docs pattern: repeated triggers should compress into a single shared stack at the top-right corner."
    >
      <button type="button" className={buttonClassName} onClick={createStack}>
        Create 3 stacked toasts
      </button>
      <button type="button" className={buttonClassName} onClick={createBurst}>
        Stress the stack
      </button>
      <button type="button" className={buttonClassName} onClick={createVaryingHeightStack}>
        Varying heights
      </button>
    </ExampleCard>
  )
}

const PromiseExamples = () => {
  const [pendingExample, setPendingExample] = React.useState<'success' | 'error' | null>(null)

  const exportDsl = async (outcome: 'success' | 'error') => {
    if (pendingExample) return

    setPendingExample(outcome)
    const request = new Promise<string>((resolve, reject) => {
      window.setTimeout(() => {
        if (outcome === 'success') resolve('customer-support-agent.yml')
        else reject(new Error('The DSL could not be generated.'))
      }, 1400)
    })

    await toast
      .promise(request, {
        loading: {
          title: 'Preparing DSL export',
          description: 'Collecting the app configuration and generating a YAML file.',
        },
        success: (fileName) => ({
          title: 'Download started',
          description: `${fileName} was sent to your browser.`,
          timeout: 3000,
        }),
        error: () => ({
          title: 'Export failed',
          description: 'The DSL could not be generated. Try again.',
        }),
      })
      .catch(() => undefined)

    setPendingExample(null)
  }

  return (
    <ExampleCard
      eyebrow="Promise"
      title="Export lifecycle"
      description="A single toast follows the export from preparation to browser handoff, while the trigger prevents duplicate requests."
    >
      <Button
        variant="secondary"
        loading={pendingExample === 'success'}
        disabled={pendingExample === 'error'}
        onClick={() => exportDsl('success')}
      >
        Export DSL
      </Button>
      <Button
        variant="secondary"
        loading={pendingExample === 'error'}
        disabled={pendingExample === 'success'}
        onClick={() => exportDsl('error')}
      >
        Simulate failure
      </Button>
    </ExampleCard>
  )
}

const ActionExamples = () => {
  const createActionToast = () => {
    let archivedToastId = ''
    archivedToastId = toast.warning('Project archived', {
      description: 'You can restore it from workspace settings for the next 30 days.',
      timeout: 10000,
      actionProps: {
        children: 'Undo',
        onClick: () => {
          toast.dismiss(archivedToastId)
          toast.success('Project restored', {
            description: 'The workspace is active again.',
          })
        },
      },
    })
  }

  const createLongCopyToast = () => {
    toast.error(longToastTitle, {
      description: longToastDescription,
      actionProps: {
        children: 'View details',
        onClick: () => {
          toast.info('Job details opened')
        },
      },
    })
  }

  return (
    <ExampleCard
      eyebrow="Action"
      title="Actionable toasts"
      description="Use these to verify the secondary action button, multi-line content, and the close affordance under tighter layouts."
    >
      <button type="button" className={buttonClassName} onClick={createActionToast}>
        Undo action
      </button>
      <button type="button" className={buttonClassName} onClick={createLongCopyToast}>
        Long content
      </button>
    </ExampleCard>
  )
}

const DeduplicateExamples = () => {
  const saveCountRef = React.useRef(0)

  const saveDraft = () => {
    saveCountRef.current += 1
    toast.success('Draft saved', {
      id: 'draft-save-status',
      description:
        saveCountRef.current === 1
          ? 'Click again while this toast is visible to update the same mounted toast.'
          : `Same toast updated ${saveCountRef.current} times.`,
    })
  }

  return (
    <ExampleCard
      eyebrow="Deduplicated"
      title="Same-id upsert"
      description="Matches the Base UI deduplicated toast example: repeated triggers use a stable id, so the visible toast is updated instead of adding another stack item."
    >
      <button type="button" className={buttonClassName} onClick={saveDraft}>
        Save draft
      </button>
    </ExampleCard>
  )
}

const UpdateExamples = () => {
  const createUpdatableToast = () => {
    const toastId = toast.info('Import started', {
      description: 'Preparing assets and metadata for processing.',
      timeout: 0,
    })

    window.setTimeout(() => {
      toast.update(toastId, {
        type: 'success',
        title: 'Import finished',
        description: '128 records were imported successfully.',
        timeout: 5000,
      })
    }, 1400)
  }

  const clearAll = () => {
    toast.dismiss()
  }

  return (
    <ExampleCard
      eyebrow="Update"
      title="Programmatic lifecycle"
      description="This example exercises manual updates on an existing toast and keeps a clear-all control nearby for repeated interaction during review."
    >
      <button type="button" className={buttonClassName} onClick={createUpdatableToast}>
        Add then update
      </button>
      <button type="button" className={buttonClassName} onClick={clearAll}>
        Clear all
      </button>
    </ExampleCard>
  )
}

const ToastDocsDemo = () => {
  return (
    <React.Fragment>
      <ToastHost />
      <div className="min-h-screen bg-background-default-subtle px-6 py-12">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-8">
          <div className="space-y-3">
            <div className="text-xs tracking-[0.18em] text-text-tertiary uppercase">
              Base UI toast docs
            </div>
            <h2 className="text-[24px] leading-8 font-semibold text-text-primary">
              Shared stacked toast examples
            </h2>
            <p className="max-w-3xl text-sm leading-6 text-text-secondary">
              Each example card below triggers the same shared toast viewport in the top-right
              corner, so you can review stacking, state transitions, actions, and tone variants the
              same way the official Base UI documentation demonstrates toast behavior.
            </p>
          </div>
          <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
            <VariantExamples />
            <StackExamples />
            <PromiseExamples />
            <ActionExamples />
            <DeduplicateExamples />
            <UpdateExamples />
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}

const meta = {
  title: 'Base/UI/Toast',
  component: ToastDocsDemo,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Dify toast host built on Base UI Toast. The story is organized as multiple example panels that all feed the same shared toast viewport, matching the way the Base UI documentation showcases toast behavior.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof ToastDocsDemo>

export default meta
type Story = StoryObj<typeof meta>

export const DocsPattern: Story = {
  render: () => <ToastDocsDemo />,
  play: async ({ canvas, canvasElement, userEvent }) => {
    const body = within(canvasElement.ownerDocument.body)

    await userEvent.click(canvas.getByRole('button', { name: 'Long content' }))

    const title = await body.findByText(longToastTitle)
    const description = await body.findByText(longToastDescription)
    expect(title.scrollWidth).toBeLessThanOrEqual(title.clientWidth)
    expect(description.scrollWidth).toBeLessThanOrEqual(description.clientWidth)
  },
}
