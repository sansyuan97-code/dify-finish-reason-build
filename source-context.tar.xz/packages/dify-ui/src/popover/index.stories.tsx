import type { Meta, StoryObj } from '@storybook/react-vite'
import type { PopoverContentProps } from '.'
import * as React from 'react'
import {
  createPopoverHandle,
  Popover,
  PopoverClose,
  PopoverContent,
  PopoverDescription,
  PopoverTitle,
  PopoverTrigger,
} from '.'
import { Button } from '../button'
import { Kbd, KbdGroup } from '../kbd'

const triggerButtonClassName =
  'rounded-lg border border-divider-subtle bg-components-button-secondary-bg px-3 py-1.5 text-sm text-text-secondary shadow-xs outline-hidden hover:bg-state-base-hover focus-visible:ring-2 focus-visible:ring-state-accent-solid'

const meta = {
  title: 'Base/UI/Popover',
  component: Popover,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Compound popover built on Base UI Popover. Use it for contextual affordances, overflow menus, filters, and forms that anchor to a trigger. Control placement via the `placement` prop on `PopoverContent` and compose arbitrary children inside the popup.\n\nPass `openOnHover` on `PopoverTrigger` when the popup should also reveal on hover (see the **Infotip** story). Unlike `Tooltip` and `PreviewCard`, hover on `Popover` still falls back to tap/focus, so touch and screen-reader users can reach the content.',
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Popover>

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  render: () => (
    <Popover>
      <PopoverTrigger render={<button type="button" className={triggerButtonClassName} />}>
        Open popover
      </PopoverTrigger>
      <PopoverContent>
        <div className="flex w-72 flex-col gap-2 p-4">
          <PopoverTitle className="text-sm font-semibold text-text-primary">
            Keyboard shortcuts
          </PopoverTitle>
          <PopoverDescription className="text-xs text-text-secondary">
            Press{' '}
            <KbdGroup>
              <Kbd>⌘</Kbd>
              <Kbd>K</Kbd>
            </KbdGroup>{' '}
            to open the command palette anywhere in the app.
          </PopoverDescription>
        </div>
      </PopoverContent>
    </Popover>
  ),
}

export const WithActions: Story = {
  render: () => (
    <Popover>
      <PopoverTrigger render={<button type="button" className={triggerButtonClassName} />}>
        Share workspace
      </PopoverTrigger>
      <PopoverContent>
        <div className="flex w-80 flex-col gap-3 p-4">
          <div className="flex flex-col gap-1">
            <PopoverTitle className="text-sm font-semibold text-text-primary">
              Share workspace
            </PopoverTitle>
            <PopoverDescription className="text-xs text-text-secondary">
              Invite collaborators by email. They will get a pending invitation in their inbox.
            </PopoverDescription>
          </div>
          <input
            type="email"
            placeholder="teammate@example.com"
            className="h-8 rounded-md border border-transparent bg-components-input-bg-normal px-2 text-sm text-components-input-text-filled outline-hidden placeholder:text-components-input-text-placeholder hover:border-components-input-border-hover hover:bg-components-input-bg-hover focus:border-components-input-border-active focus:bg-components-input-bg-active focus:shadow-xs"
          />
          <div className="flex items-center justify-end gap-2">
            <PopoverClose render={<Button variant="secondary" size="small" />}>Cancel</PopoverClose>
            <PopoverClose render={<Button variant="primary" size="small" />}>
              Send invite
            </PopoverClose>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  ),
}

type ResourcePopoverPayload = {
  label: string
  description: string
}

const resourcePopoverPayloads = [
  {
    label: 'Knowledge base',
    description: 'Searches indexed documents before the model generates an answer.',
  },
  {
    label: 'HTTP request',
    description: 'Calls an external endpoint with values from the current workflow.',
  },
] as const satisfies readonly ResourcePopoverPayload[]

function DetachedTriggersDemo() {
  const [popoverHandle] = React.useState(() => createPopoverHandle<ResourcePopoverPayload>())

  return (
    <div className="flex gap-2">
      {resourcePopoverPayloads.map((payload) => (
        <PopoverTrigger
          key={payload.label}
          handle={popoverHandle}
          payload={payload}
          render={<button type="button" className={triggerButtonClassName} />}
        >
          {payload.label}
        </PopoverTrigger>
      ))}

      <Popover handle={popoverHandle}>
        {({ payload }) => (
          <PopoverContent>
            <div className="flex w-72 flex-col gap-1 p-4">
              <PopoverTitle className="text-sm font-semibold text-text-primary">
                {payload?.label ?? 'Resource'}
              </PopoverTitle>
              <PopoverDescription className="text-xs text-text-secondary">
                {payload?.description ?? 'Choose a resource to learn more.'}
              </PopoverDescription>
            </div>
          </PopoverContent>
        )}
      </Popover>
    </div>
  )
}

export const DetachedTriggers: Story = {
  render: () => <DetachedTriggersDemo />,
}

export const Infotip: Story = {
  parameters: {
    docs: {
      description: {
        story: [
          'The **infotip** pattern from [Base UI](https://base-ui.com/react/components/tooltip#infotips): an info glyph (`?`, `(i)`) whose sole purpose is to reveal explanatory text. Use `Popover` with `openOnHover` on the trigger — never `Tooltip`.',
          '',
          "Why not `Tooltip`? Tooltips are disabled on touch devices and not announced to screen readers; descriptive help text hidden in them is unreachable for those users. Why not `PreviewCard`? PreviewCard's a11y contract requires the trigger to already own a primary click destination, but an info glyph has no other purpose.",
          '',
          "Base UI rule of thumb: *\"If the trigger's purpose is to open the popup itself, it's a popover. If the trigger's purpose is unrelated to opening the popup, it's a tooltip.\"*",
          '',
          'Hover, tap, or focus the `?` icon to open. In the Dify app, reach for `@/app/components/base/infotip` (`<Infotip aria-label={...}>{helpText}</Infotip>`) which wraps this pattern with consistent delays (300/200), typography, and `aria-label` plumbing.',
        ].join('\n'),
      },
    },
  },
  render: () => (
    <div className="flex items-center gap-2 text-sm font-medium text-text-secondary">
      <span>Usage priority</span>
      <Popover>
        <PopoverTrigger
          openOnHover
          delay={300}
          closeDelay={200}
          aria-label="Set which resource to use first when running models."
          render={
            <button
              type="button"
              className="inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-sm focus-visible:ring-2 focus-visible:ring-state-accent-solid focus-visible:outline-hidden"
            >
              <span
                aria-hidden
                className="i-ri-question-line h-3.5 w-3.5 text-text-quaternary hover:text-text-tertiary"
              />
            </button>
          }
        />
        <PopoverContent
          placement="top"
          className="max-w-75 px-3 py-2 system-xs-regular text-text-tertiary"
        >
          Set which resource to use first when running models. The Trial quota will be used after
          the paid quota is exhausted.
        </PopoverContent>
      </Popover>
    </div>
  ),
}

type PopoverPlacement = NonNullable<PopoverContentProps['placement']>

const PLACEMENTS: PopoverPlacement[] = [
  'top-start',
  'top',
  'top-end',
  'right-start',
  'right',
  'right-end',
  'bottom-start',
  'bottom',
  'bottom-end',
  'left-start',
  'left',
  'left-end',
]

const PlacementsDemo = () => {
  const [placement, setPlacement] = React.useState<PopoverPlacement>('bottom')

  return (
    <div className="flex flex-col items-center gap-4 p-20">
      <div className="grid grid-cols-3 gap-2 text-xs">
        {PLACEMENTS.map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setPlacement(value)}
            className={`rounded-md border border-divider-subtle px-2 py-1 text-text-secondary focus-visible:ring-2 focus-visible:ring-state-accent-solid focus-visible:outline-hidden ${
              placement === value ? 'bg-state-base-hover' : 'bg-components-button-secondary-bg'
            }`}
          >
            {value}
          </button>
        ))}
      </div>
      <Popover open>
        <PopoverTrigger render={<button type="button" className={triggerButtonClassName} />}>
          Anchored trigger
        </PopoverTrigger>
        <PopoverContent placement={placement}>
          <div className="flex w-56 flex-col gap-1 p-3">
            <PopoverTitle className="text-sm font-semibold text-text-primary">
              placement="
              {placement}"
            </PopoverTitle>
            <PopoverDescription className="text-xs text-text-secondary">
              Popover positions itself relative to the trigger using the selected placement.
            </PopoverDescription>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}

export const Placements: Story = {
  parameters: {
    layout: 'fullscreen',
  },
  render: () => <PlacementsDemo />,
}

const ControlledDemo = () => {
  const [open, setOpen] = React.useState(false)

  return (
    <div className="flex items-center gap-3">
      <Button variant="secondary" onClick={() => setOpen((prev) => !prev)}>
        {open ? 'Close from outside' : 'Open from outside'}
      </Button>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger render={<button type="button" className={triggerButtonClassName} />}>
          Anchor
        </PopoverTrigger>
        <PopoverContent>
          <div className="flex w-64 flex-col gap-2 p-4">
            <PopoverTitle className="text-sm font-semibold text-text-primary">
              Controlled popover
            </PopoverTitle>
            <PopoverDescription className="text-xs text-text-secondary">
              Open state is owned by the parent. The trigger and the external button both toggle it.
            </PopoverDescription>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}

export const Controlled: Story = {
  render: () => <ControlledDemo />,
}
