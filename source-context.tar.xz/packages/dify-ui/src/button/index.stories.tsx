import type { Meta, StoryObj } from '@storybook/react-vite'
import type { ButtonProps } from '.'
import * as React from 'react'
import { expect, fn } from 'storybook/test'
import { Button, buttonVariants } from '.'

type LoadingButtonExampleProps = Pick<ButtonProps, 'onClick' | 'variant'>

function LoadingButtonExample({ onClick, variant }: LoadingButtonExampleProps) {
  const [loading, setLoading] = React.useState(false)
  const labelId = React.useId()

  return (
    <Button
      aria-labelledby={labelId}
      loading={loading}
      onClick={(event) => {
        onClick?.(event)
        setLoading(true)
      }}
      variant={variant}
    >
      <span id={labelId}>{loading ? 'Saving' : 'Save'}</span>
    </Button>
  )
}

const meta = {
  title: 'Base/UI/Button',
  component: Button,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    loading: { control: 'boolean' },
    focusableWhenDisabled: { control: 'boolean' },
    tone: {
      control: 'select',
      options: ['default', 'destructive'],
    },
    disabled: { control: 'boolean' },
    variant: {
      control: 'select',
      options: ['primary', 'secondary', 'secondary-accent', 'ghost', 'ghost-accent', 'tertiary'],
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
    },
  },
  args: {
    variant: 'ghost',
    children: 'Button',
  },
} satisfies Meta<typeof Button>

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    variant: 'primary',
    children: 'Primary Button',
  },
}

export const Secondary: Story = {
  args: {
    variant: 'secondary',
    children: 'Secondary Button',
  },
}

export const SecondaryAccent: Story = {
  args: {
    variant: 'secondary-accent',
    children: 'Secondary Accent Button',
  },
}

export const Ghost: Story = {
  args: {
    variant: 'ghost',
    children: 'Ghost Button',
  },
}

export const GhostAccent: Story = {
  args: {
    variant: 'ghost-accent',
    children: 'Ghost Accent Button',
  },
}

export const Tertiary: Story = {
  args: {
    variant: 'tertiary',
    children: 'Tertiary Button',
  },
}

export const Disabled: Story = {
  args: {
    variant: 'primary',
    disabled: true,
    children: 'Disabled Button',
  },
}

export const Loading: Story = {
  args: {
    variant: 'primary',
    onClick: fn(),
  },
  render: ({ onClick, variant }) => <LoadingButtonExample onClick={onClick} variant={variant} />,
  play: async ({ args, canvas, userEvent }) => {
    const button = canvas.getByRole('button', { name: 'Save' })

    button.focus()
    await expect(button).toHaveFocus()

    await userEvent.click(button)
    await expect(args.onClick).toHaveBeenCalledTimes(1)
    await expect(button).toHaveAccessibleName('Saving')
    await expect(button).toHaveAttribute('aria-disabled', 'true')
    await expect(button).not.toHaveAttribute('aria-busy')
    await expect(button).toHaveFocus()

    await userEvent.keyboard('{Enter}')
    await expect(args.onClick).toHaveBeenCalledTimes(1)
  },
  parameters: {
    docs: {
      description: {
        story:
          'When a focused button changes its visible label during loading, give that label a stable ID and reference it with `aria-labelledby`. Loading blocks repeated activation while retaining focus.',
      },
    },
  },
}

export const Destructive: Story = {
  args: {
    variant: 'primary',
    tone: 'destructive',
    children: 'Delete',
  },
}

export const WithIcon: Story = {
  args: {
    variant: 'primary',
    size: 'medium',
    children: 'Launch',
  },
  render: (args) => {
    const iconSize =
      args.size === 'small' ? 'size-3.5' : args.size === 'large' ? 'size-5' : 'size-4'

    return (
      <Button {...args}>
        <span aria-hidden className={`i-ri-rocket-line shrink-0 ${iconSize}`} />
        {args.children}
      </Button>
    )
  },
}

export const SmallSize: Story = {
  args: {
    variant: 'secondary',
    size: 'small',
    children: 'Small',
  },
}

export const LargeSize: Story = {
  args: {
    variant: 'primary',
    size: 'large',
    children: 'Large Button',
  },
}

export const StyledLink: Story = {
  render: () => (
    <a className={buttonVariants({ variant: 'ghost-accent' })} href="https://example.com">
      Link styled as a button
    </a>
  ),
  play: async ({ canvas }) => {
    await expect(canvas.getByRole('link', { name: 'Link styled as a button' })).toHaveAttribute(
      'href',
      'https://example.com',
    )
  },
  parameters: {
    docs: {
      description: {
        story:
          'Rendering an anchor through `Button` is an anti-pattern because Base UI enforces button semantics. Keep the native link and apply `buttonVariants` directly when a link needs button styling. See the [Base UI Button usage guidelines](https://base-ui.com/react/components/button#rendering-links-as-buttons).',
      },
    },
  },
}
