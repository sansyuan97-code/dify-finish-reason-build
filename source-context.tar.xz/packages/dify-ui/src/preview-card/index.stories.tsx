import type { Meta, StoryObj } from '@storybook/react-vite'
import type { PreviewCardContentProps } from '.'
import * as React from 'react'
import { createPreviewCardHandle, PreviewCard, PreviewCardContent, PreviewCardTrigger } from '.'

const triggerButtonClassName =
  'rounded-lg border border-divider-subtle bg-components-button-secondary-bg px-3 py-1.5 text-sm text-text-secondary shadow-xs outline-hidden hover:bg-state-base-hover focus-visible:ring-2 focus-visible:ring-state-accent-solid'

const inlineLinkClassName =
  'text-text-accent underline decoration-text-accent/60 decoration-1 underline-offset-2 outline-hidden hover:decoration-text-accent focus-visible:rounded-xs focus-visible:no-underline focus-visible:ring-1 focus-visible:ring-components-input-border-active data-[popup-open]:decoration-text-accent'

const meta = {
  title: 'Base/UI/PreviewCard',
  component: PreviewCard,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "A visual enhancement for a link that previews its destination, built on Base UI PreviewCard. The popup is unavailable to touch and screen-reader users, so it must remain non-interactive and must not contain unique or essential information unless that information is also available at the linked destination. Use Popover when opening the popup is the trigger's purpose or when its content must be accessible across input modes.",
      },
    },
  },
  tags: ['autodocs'],
} satisfies Meta<typeof PreviewCard>

export default meta
type Story = StoryObj<typeof meta>

// --- Canonical: inline link preview ---------------------------------------
// Mirrors Base UI's own PreviewCard docs demo: an inline `<a href>` in a
// paragraph, hovering reveals a rich preview (image + summary) of the link's
// destination. The Wikipedia URL and Unsplash image are the exact assets used
// in base-ui.com's public docs so the story renders a real preview.
// https://base-ui.com/react/components/preview-card
type TypographyPreviewPayload = {
  title: string
  description: string
  image: {
    src: string
    alt: string
  }
}

const typographyPreviewPayload = {
  title: 'Typography',
  description:
    'Typography is the art and science of arranging type to make written language legible, readable, and visually appealing.',
  image: {
    src: 'https://images.unsplash.com/photo-1619615391095-dfa29e1672ef?q=80&w=448&h=300',
    alt: 'Station Hofplein signage in Rotterdam, Netherlands',
  },
} satisfies TypographyPreviewPayload

function LinkPreviewDemo() {
  const [previewCardHandle] = React.useState(() =>
    createPreviewCardHandle<TypographyPreviewPayload>(),
  )

  return (
    <div className="max-w-md p-6 text-sm leading-6 text-text-secondary">
      <p>
        The principles of good{' '}
        <PreviewCardTrigger
          handle={previewCardHandle}
          payload={typographyPreviewPayload}
          href="https://en.wikipedia.org/wiki/Typography"
          target="_blank"
          rel="noreferrer"
          className={inlineLinkClassName}
        >
          typography
        </PreviewCardTrigger>{' '}
        remain in the digital age.
      </p>

      <PreviewCard handle={previewCardHandle}>
        {({ payload = typographyPreviewPayload }) => (
          <PreviewCardContent className="w-60 p-2">
            <div className="flex flex-col gap-2">
              <img
                width="224"
                height="150"
                className="block max-w-none rounded-md"
                src={payload.image.src}
                alt={payload.image.alt}
              />
              <p className="m-0 text-xs leading-5 text-text-secondary">
                <strong className="text-text-primary">{payload.title}</strong> {payload.description}
              </p>
            </div>
          </PreviewCardContent>
        )}
      </PreviewCard>
    </div>
  )
}

export const LinkPreview: Story = {
  name: 'Link preview (canonical)',
  parameters: {
    docs: {
      description: {
        story:
          'The prototypical PreviewCard use case: an inline hyperlink with a rich hover preview of the destination. Uses a detached trigger + `createPreviewCardHandle()` so the trigger can sit inline in prose while the popup content is defined elsewhere. The trigger renders a real `<a href>` — click still follows the link; the preview is strictly supplementary.',
      },
    },
  },
  render: () => <LinkPreviewDemo />,
}

type PreviewCardPlacement = NonNullable<PreviewCardContentProps['placement']>

const PLACEMENTS: PreviewCardPlacement[] = [
  'top-start',
  'top',
  'top-end',
  'right-start',
  'right',
  'right-end',
  'bottom-start',
  'bottom',
  'bottom-end',
  'left-start',
  'left',
  'left-end',
]

const PlacementsDemo = () => {
  const [placement, setPlacement] = React.useState<PreviewCardPlacement>('bottom')

  return (
    <div className="flex flex-col items-center gap-4 p-20">
      <div className="grid grid-cols-3 gap-2 text-xs">
        {PLACEMENTS.map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setPlacement(value)}
            className={`rounded-md border border-divider-subtle px-2 py-1 text-text-secondary focus-visible:ring-2 focus-visible:ring-state-accent-solid focus-visible:outline-hidden ${
              placement === value ? 'bg-state-base-hover' : 'bg-components-button-secondary-bg'
            }`}
          >
            {value}
          </button>
        ))}
      </div>
      <PreviewCard open>
        <PreviewCardTrigger href="#preview-card-placement" className={triggerButtonClassName}>
          Hover me
        </PreviewCardTrigger>
        <PreviewCardContent placement={placement} className="w-56 p-3">
          <div className="flex flex-col gap-1">
            <div className="text-sm font-semibold text-text-primary">
              placement="
              {placement}"
            </div>
            <div className="text-xs text-text-secondary">
              Preview positions itself relative to the trigger.
            </div>
          </div>
        </PreviewCardContent>
      </PreviewCard>
    </div>
  )
}

export const Placements: Story = {
  parameters: {
    layout: 'fullscreen',
  },
  render: () => <PlacementsDemo />,
}

const CustomDelayDemo = () => (
  <PreviewCard>
    <PreviewCardTrigger
      delay={100}
      closeDelay={100}
      href="#preview-card-delay"
      className={triggerButtonClassName}
    >
      Snappy trigger
    </PreviewCardTrigger>
    <PreviewCardContent className="w-64 p-3">
      <div className="flex flex-col gap-1">
        <div className="text-sm font-semibold text-text-primary">Fast hover</div>
        <div className="text-xs text-text-secondary">
          Base UI defaults (600ms / 300ms) are tuned for link previews. Override per trigger for
          denser UIs.
        </div>
      </div>
    </PreviewCardContent>
  </PreviewCard>
)

export const CustomDelays: Story = {
  render: () => <CustomDelayDemo />,
}
